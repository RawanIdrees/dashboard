

        <?php $__env->startSection('content'); ?>
        <div class="title-section">
            <h1>Our Computers</h1>
        </div>

        <!-- Computer List -->
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="computer-item">
                        <h5>Keyboard 1</h5>
                        <p>High-performance PC for gaming and work.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="computer-item">
                        <h5>Keyboard 2</h5>
                        <p>Compact and affordable desktop solution.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="computer-item">
                        <h5>Keyboard 3</h5>
                        <p>Powerful workstation for professionals.</p>
                    </div>
                </div>
            </div>
        </div>
        <?php $__env->stopSection(); ?>
   
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\computer\resources\views/keyboard.blade.php ENDPATH**/ ?>