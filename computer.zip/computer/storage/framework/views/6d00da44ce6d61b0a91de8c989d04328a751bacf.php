
<?php $__env->startSection('content'); ?>
<div class="title-section">
</div>

<!-- Computer List -->
<div class="container">
<h1 style="text-align: center; padding-bottom:15px"><b>Our Computer Products</b></h1>
<div class="product_container">
    <!-- Card 1 -->
    <div class="card">
        <h3><?php echo e($computer['name']); ?></h3>
        <p>Country of Origin: <b><?php echo e($computer['origin']); ?></b></p>
        <p class="price"><?php echo e($computer['price']); ?>$</p>
        <a href="<?php echo e(route('computers.edit',$computer['id'])); ?>" class="btn">Edit Information</a>
        
        <!-- Form for deleting -->
        <form action="<?php echo e(route('computers.destroy',$computer->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn delete">Delete</button> <!-- تغيير هنا إلى button -->
        </form>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\computer\resources\views/show.blade.php ENDPATH**/ ?>