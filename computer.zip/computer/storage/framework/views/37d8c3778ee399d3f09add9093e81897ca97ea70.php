
<?php $__env->startSection('content'); ?>
<div class="form-container">
        <h2><b>Edit Computer</b></h2>
        <form action="<?php echo e(route('computers.update',$computer->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <!-- Token for CSRF in Laravel -->            
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text"  name="name" value="<?php echo e(old('name',$computer->name)); ?>" >
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text_danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="origin">Country of Origin</label>
                <input type="text"  name="origin" value="<?php echo e(old('origin',$computer->origin)); ?>" >
                <?php $__errorArgs = ['origin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text_danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number"  name="price" value="<?php echo e(old('price',$computer->price)); ?>" step="0.01" >
                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text_danger"><?php echo e($message); ?></span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn save">Save</button>
            </div>
        </form>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\computer\resources\views/edit.blade.php ENDPATH**/ ?>