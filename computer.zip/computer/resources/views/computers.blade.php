@extends('layout')
@section('content')
<div class="title-section">
    <h1><b>Our Computers</b></h1>
    <!-- زر إضافة منتج جديد -->
</div>

<!-- Computer List -->
<div class="container">
<a href="{{ route('computers.create') }}" class="btn btn-primary">Add New Product</a>

    <div class="row">
        @foreach($computers as $comp)
        <div class="col-md-4 mb-4">
            <a href="{{ route('computers.show', $comp['id']) }}">
            <div class="computer-item">
                <h2><b>{{ $comp['name'] }}</b></h2>
                <h6>Computer 1</h6>
            </div>
            </a>
        </div>
        @endforeach
    </div>
</div>
@endsection

