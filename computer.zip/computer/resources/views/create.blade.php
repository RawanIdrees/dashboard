@extends('layout')
@section('content')
<div class="form-container">
        <h2><b>Add New Computer</b></h2>
        <form action="{{ route('computers.store') }}" method="POST">
        @csrf
            <!-- Token for CSRF in Laravel -->            
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text"  name="name" value="{{old('name')}}" >
                @error('name')
            <span class="text_danger">{{ $message }}</span>
        @enderror
            </div>
            <div class="form-group">
                <label for="origin">Country of Origin</label>
                <input type="text"  name="origin" value="{{old('origin')}}" >
                @error('origin')
            <span class="text_danger">{{ $message }}</span>
        @enderror
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number"  name="price" value="{{old('price')}}" step="0.01" >
                @error('price')
            <span class="text_danger">{{ $message }}</span>
        @enderror
            </div>
            <div class="form-actions">
                <button type="submit" class="btn save">Save</button>
            </div>
        </form>
    </div>
    @endsection