@extends('layout')
@section('content')
<div class="form-container">
        <h2><b>Edit Computer</b></h2>
        <form action="{{route('computers.update',$computer->id)}}" method="POST">
        @csrf
            @method('PUT')
            <!-- Token for CSRF in Laravel -->            
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text"  name="name" value="{{old('name',$computer->name)}}" >
                @error('name')
            <span class="text_danger">{{ $message }}</span>
        @enderror
            </div>
            <div class="form-group">
                <label for="origin">Country of Origin</label>
                <input type="text"  name="origin" value="{{old('origin',$computer->origin)}}" >
                @error('origin')
            <span class="text_danger">{{ $message }}</span>
        @enderror
            </div>
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number"  name="price" value="{{old('price',$computer->price)}}" step="0.01" >
                @error('price')
            <span class="text_danger">{{ $message }}</span>
        @enderror
            </div>
            <div class="form-actions">
                <button type="submit" class="btn save">Save</button>
            </div>
        </form>
    </div>
    @endsection