@extends('layout')
@section('content')
<div class="title-section">
</div>

<!-- Computer List -->
<div class="container">
<h1 style="text-align: center; padding-bottom:15px"><b>Our Computer Products</b></h1>
<div class="product_container">
    <!-- Card 1 -->
    <div class="card">
        <h3>{{$computer['name']}}</h3>
        <p>Country of Origin: <b>{{$computer['origin']}}</b></p>
        <p class="price">{{$computer['price']}}$</p>
        <a href="{{route('computers.edit',$computer['id'])}}" class="btn">Edit Information</a>
        
        <!-- Form for deleting -->
        <form action="{{route('computers.destroy',$computer->id)}}" method="POST">
            @csrf
            @method('DELETE')
            <button type="submit" class="btn delete">Delete</button> <!-- تغيير هنا إلى button -->
        </form>
    </div>
</div>

</div>
@endsection
