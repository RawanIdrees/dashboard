<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel='stylesheet' href="{{url('css/style.css')}}">
    </head>
    <body class="antialiased">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="#">Tech Store</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                    <a class="nav-link active" href="{{route('computers.index')}}">
                      
                        Computers</a>

                        <a class="nav-link" href="{{route('home.mouse')}}">
                       
                        Mouses</a>

                        <a class="nav-link" href="{{route('home.Keyboard')}}">
                       
                        Keyboard</a>
                    </ul>
                </div>
            </div>
        </nav>
        @yield('content')
       
    </body>
</html>
