
@extends('layout')
        @section('content')
        <div class="title-section">
            <h1>Our Computers</h1>
        </div>

        <!-- Computer List -->
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="computer-item">
                        <h5>Mouse 1</h5>
                        <p>High-performance PC for gaming and work.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="computer-item">
                        <h5>Mouse 2</h5>
                        <p>Compact and affordable desktop solution.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="computer-item">
                        <h5>Mouse 3</h5>
                        <p>Powerful workstation for professionals.</p>
                    </div>
                </div>
            </div>
        </div>
        @endsection
   