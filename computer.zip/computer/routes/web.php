<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ComputerController;




Route::get('/mouses', function () {
    return view('mouses');
})->name('home.mouse');



Route::get('/keyboards', function () {
    return view('keyboard');
})->name('home.Keyboard');

Route::resource('/computers',ComputerController::class);

